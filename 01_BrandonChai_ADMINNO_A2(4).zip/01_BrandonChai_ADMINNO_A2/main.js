/* CanVerse page management, learning interactions and mini-game. */

// -------------------- PAGE MANAGEMENT --------------------
const allPages = document.querySelectorAll(".page");
const allNavButtons = document.querySelectorAll(".nav-button");
const homeNav = document.querySelector("#homeNav");
const benefitsNav = document.querySelector("#benefitsNav");
const regulationsNav = document.querySelector("#regulationsNav");
const quizNav = document.querySelector("#quizNav");
const gameNav = document.querySelector("#gameNav");
const homeButton = document.querySelector("#homeButton");
const benefitsStart = document.querySelector("#benefitsStart");
const gameStart = document.querySelector("#gameStart");
const menuButton = document.querySelector("#menuButton");
const menuLabel = document.querySelector("#menuLabel");
const mainNav = document.querySelector("#mainNav");
const soundButton = document.querySelector("#soundButton");

var currentPage = 1;
var soundOn = true;

const clickAudio = new Audio("audio/click.wav");
const correctAudio = new Audio("audio/correct.wav");
const wrongAudio = new Audio("audio/wrong.wav");

function playSound(audioObject) {
    if (soundOn == true) {
        audioObject.play();
    }
}

function hideall() {
    for (let onePage of allPages) {
        onePage.style.display = "none";
    }
}

function removeActiveNav() {
    for (let oneButton of allNavButtons) {
        oneButton.classList.remove("active");
    }
}

function showPage(pageName, pageNumber, navButton) {
    hideall();
    removeActiveNav();

    const selectedPage = document.querySelector("#" + pageName);
    selectedPage.style.display = "block";
    selectedPage.classList.add("page-enter");
    navButton.classList.add("active");
    currentPage = pageNumber;

    mainNav.classList.remove("menuShow");
    menuLabel.innerHTML = "☰ Menu";
    playSound(clickAudio);
}

homeNav.addEventListener("click", function () {
    showPage("home", 1, homeNav);
});

benefitsNav.addEventListener("click", function () {
    showPage("benefits", 2, benefitsNav);
});

regulationsNav.addEventListener("click", function () {
    showPage("regulations", 3, regulationsNav);
});

quizNav.addEventListener("click", function () {
    showPage("quiz", 4, quizNav);
});

gameNav.addEventListener("click", function () {
    showPage("game", 5, gameNav);
});

homeButton.addEventListener("click", function () {
    showPage("home", 1, homeNav);
});

benefitsStart.addEventListener("click", function () {
    showPage("benefits", 2, benefitsNav);
});

gameStart.addEventListener("click", function () {
    showPage("game", 5, gameNav);
});

menuButton.addEventListener("click", function () {
    mainNav.classList.toggle("menuShow");

    if (mainNav.classList.contains("menuShow")) {
        menuLabel.innerHTML = "✕ Close";
    } else {
        menuLabel.innerHTML = "☰ Menu";
    }
});

soundButton.addEventListener("click", function () {
    if (soundOn == true) {
        soundOn = false;
        soundButton.innerHTML = "Sound: Off";
        soundButton.classList.add("muted");
    } else {
        soundOn = true;
        soundButton.innerHTML = "Sound: On";
        soundButton.classList.remove("muted");
        playSound(clickAudio);
    }
});

document.addEventListener("keydown", function (event) {
    if (event.code == "ArrowRight") {
        if (currentPage == 1) {
            showPage("benefits", 2, benefitsNav);
        } else if (currentPage == 2) {
            showPage("regulations", 3, regulationsNav);
        } else if (currentPage == 3) {
            showPage("quiz", 4, quizNav);
        } else if (currentPage == 4) {
            showPage("game", 5, gameNav);
        } else {
            showPage("home", 1, homeNav);
        }
    }

    if (event.code == "ArrowLeft") {
        if (currentPage == 1) {
            showPage("game", 5, gameNav);
        } else if (currentPage == 2) {
            showPage("home", 1, homeNav);
        } else if (currentPage == 3) {
            showPage("benefits", 2, benefitsNav);
        } else if (currentPage == 4) {
            showPage("regulations", 3, regulationsNav);
        } else {
            showPage("quiz", 4, quizNav);
        }
    }
});

// -------------------- BENEFIT EXPLORER --------------------
const benefit1 = document.querySelector("#benefit1");
const benefit2 = document.querySelector("#benefit2");
const benefit3 = document.querySelector("#benefit3");
const benefit4 = document.querySelector("#benefit4");
const allBenefitCards = document.querySelectorAll(".ingredient-card");
const benefitDetail = document.querySelector("#benefitDetail");
const benefitName = document.querySelector("#benefitName");
const benefitText = document.querySelector("#benefitText");
const benefitNoteTitle = document.querySelector("#benefitNoteTitle");
const benefitNoteText = document.querySelector("#benefitNoteText");
const detailCan = document.querySelector("#detailCan");

const benefitTitleArray = [
    "Protection: a strong seal",
    "Portability: light and stackable",
    "Convenience: ready to serve",
    "Recyclability: useful metal"
];

const benefitTextArray = [
    "The sealed aluminium package blocks light and limits contact with air. It helps protect the drink during storage and transport.",
    "Cans are light, compact and easy to stack. These features make soft drinks easier to carry, store and transport in large numbers.",
    "A sealed single container is easy to store and open. Metal also transfers heat quickly, so a can can be chilled efficiently.",
    "Used aluminium cans can be collected, sorted and processed into material for new products instead of being treated as ordinary waste."
];

const benefitNoteTitleArray = [
    "Why it matters",
    "Transport benefit",
    "Everyday benefit",
    "The condition matters"
];

const benefitNoteTextArray = [
    "A tough package reduces leaks and damage before the drink reaches the user.",
    "Regular shapes use shelf and delivery space efficiently.",
    "The package makes serving simple at shops, events and homes.",
    "An empty and correctly returned can is easier to recover for recycling."
];

const benefitSpriteArray = [
    "can-sprite sprite-water detail-can",
    "can-sprite sprite-fizz detail-can",
    "can-sprite sprite-flavour detail-can",
    "can-sprite sprite-recycle detail-can"
];

function showBenefit(benefitNumber, selectedButton) {
    for (let oneCard of allBenefitCards) {
        oneCard.classList.remove("selected");
    }

    selectedButton.classList.add("selected");
    benefitName.innerHTML = benefitTitleArray[benefitNumber];
    benefitText.innerHTML = benefitTextArray[benefitNumber];
    benefitNoteTitle.innerHTML = benefitNoteTitleArray[benefitNumber];
    benefitNoteText.innerHTML = benefitNoteTextArray[benefitNumber];
    detailCan.className = benefitSpriteArray[benefitNumber];

    benefitDetail.classList.remove("flash");
    setTimeout(function () {
        benefitDetail.classList.add("flash");
    }, 20);

    playSound(clickAudio);
}

benefit1.addEventListener("click", function () {
    showBenefit(0, benefit1);
});

benefit2.addEventListener("click", function () {
    showBenefit(1, benefit2);
});

benefit3.addEventListener("click", function () {
    showBenefit(2, benefit3);
});

benefit4.addEventListener("click", function () {
    showBenefit(3, benefit4);
});

// -------------------- SINGAPORE REGULATIONS --------------------
const rule1 = document.querySelector("#rule1");
const rule2 = document.querySelector("#rule2");
const rule3 = document.querySelector("#rule3");
const rule4 = document.querySelector("#rule4");
const allRuleButtons = document.querySelectorAll(".journey-step");
const regulationProgress = document.querySelector("#regulationProgress");
const regulationKicker = document.querySelector("#regulationKicker");
const regulationTitle = document.querySelector("#regulationTitle");
const regulationText = document.querySelector("#regulationText");
const regulationTip = document.querySelector("#regulationTip");

const regulationKickerArray = [
    "Rule 1 - Nutrition information",
    "Rule 2 - Prepacked food label",
    "Rule 3 - Advertising",
    "Rule 4 - Beverage Container Return Scheme"
];

const regulationTitleArray = [
    "Nutri-Grade A to D",
    "Important details must be shown",
    "Grade D advertising is restricted",
    "A 10-cent refundable deposit"
];

const regulationTextArray = [
    "Prepacked soft drinks are graded A, B, C or D according to their sugar and saturated-fat content. Grade C and D drinks must show the Nutri-Grade mark on the front of the package.",
    "A prepacked drink label must give an accurate English product name, a complete ingredient list, allergens and net quantity. Imported products also identify the local importer and country of origin.",
    "Advertisements promoting Nutri-Grade D beverages are generally prohibited across media. Limited point-of-sale exceptions apply to prepacked drinks in variety shops such as supermarkets.",
    "Eligible metal and plastic drink containers from 150 millilitres to 3 litres carry a Deposit Mark. Return the empty, uncrushed container with a readable barcode at a Return Right machine to claim the refund."
];

const regulationTipArray = [
    "<strong>Remember:</strong> Showing the mark is optional for Grade A and B drinks.",
    "<strong>Read carefully:</strong> Ingredients are listed in descending order by weight.",
    "<strong>Purpose:</strong> The restriction reduces the influence of advertising on drink choices.",
    "<strong>July 2026:</strong> The transition period runs until 30 September 2026; check for the Deposit Mark."
];

function showRegulation(ruleNumber, selectedButton) {
    for (let oneButton of allRuleButtons) {
        oneButton.classList.remove("active");
    }

    selectedButton.classList.add("active");
    regulationKicker.innerHTML = regulationKickerArray[ruleNumber];
    regulationTitle.innerHTML = regulationTitleArray[ruleNumber];
    regulationText.innerHTML = regulationTextArray[ruleNumber];
    regulationTip.innerHTML = regulationTipArray[ruleNumber];
    regulationProgress.style.width = (12.5 + ruleNumber * 25) + "%";
    playSound(clickAudio);
}

rule1.addEventListener("click", function () {
    showRegulation(0, rule1);
});

rule2.addEventListener("click", function () {
    showRegulation(1, rule2);
});

rule3.addEventListener("click", function () {
    showRegulation(2, rule3);
});

rule4.addEventListener("click", function () {
    showRegulation(3, rule4);
});

// -------------------- MINI-GAME --------------------
const gameForm = document.querySelector("#gameForm");
const startGameButton = document.querySelector("#startGameButton");
const playerName = document.querySelector("#playerName");
const gameArea = document.querySelector("#gameArea");
const gameBoard = document.querySelector("#gameBoard");
const movingCan = document.querySelector("#movingCan");
const answerOptions = document.querySelector("#answerOptions");
const questionText = document.querySelector("#questionText");
const feedbackText = document.querySelector("#feedbackText");
const playerDisplay = document.querySelector("#playerDisplay");
const roundDisplay = document.querySelector("#roundDisplay");
const scoreDisplay = document.querySelector("#scoreDisplay");
const timerDisplay = document.querySelector("#timerDisplay");
const timerBox = document.querySelector(".timer-box");
const resultPanel = document.querySelector("#resultPanel");
const resultTitle = document.querySelector("#resultTitle");
const resultMessage = document.querySelector("#resultMessage");
const restartButton = document.querySelector("#restartButton");
const resetButton = document.querySelector("#resetButton");

const questionArray = [
    "A sealed can blocks light and limits contact with air.",
    "Being light and stackable gives cans this benefit.",
    "The metal commonly used for soft-drink cans.",
    "Singapore grades drinks A to D using these two nutrients.",
    "Grades C and D must show this on the front of the package.",
    "Advertisements for drinks with this Nutri-Grade are generally prohibited.",
    "Ingredients must be listed in this order.",
    "This symbol shows that a can qualifies for the return refund.",
    "The refundable amount for an eligible container.",
    "A returned can should be in this condition."
];

const answerArray = [
    "Protection",
    "Portability",
    "Aluminium",
    "Sugar and saturated fat",
    "Nutri-Grade mark",
    "Grade D",
    "Descending by weight",
    "Deposit Mark",
    "10 cents",
    "Empty and uncrushed"
];

const optionAArray = [
    "Protection",
    "Convenience",
    "Steel",
    "Protein and fibre",
    "Deposit Mark",
    "Grade A",
    "Alphabetical order",
    "Nutri-Grade mark",
    "20 cents",
    "Full and crushed"
];

const optionBArray = [
    "Decoration",
    "Portability",
    "Glass",
    "Sugar and saturated fat",
    "Nutri-Grade mark",
    "Grade B",
    "Newest first",
    "Barcode only",
    "10 cents",
    "Empty and uncrushed"
];

const optionCArray = [
    "Heating",
    "Sweetness",
    "Aluminium",
    "Salt and calcium",
    "Price label",
    "Grade C",
    "Descending by weight",
    "Deposit Mark",
    "5 cents",
    "Opened and flattened"
];

const optionDArray = [
    "Colouring",
    "Acidity",
    "Paper",
    "Water and vitamins",
    "Expiry date",
    "Grade D",
    "Shortest first",
    "Ingredient list",
    "50 cents",
    "Half-full and open"
];

var roundNumber = 0;
var score = 0;
var timeLimit = 8;
var timeLeft = 8;
var questionNumber = 0;
var randomStart = 0;
var timerIntervalId;
var moveIntervalId;
var nextQuestionTimeoutId;
var canLeft = 0;
var canVelocity = 1;
var gameIsActive = false;
var answerLocked = false;
const totalRounds = 6;

function GetRandom(min, max) {
    return Math.round(Math.random() * (max - min)) + min;
}

function stopGameTimers() {
    clearInterval(timerIntervalId);
    clearInterval(moveIntervalId);
    clearTimeout(nextQuestionTimeoutId);
}

function MoveCan() {
    canLeft = canLeft + canVelocity;

    if (canLeft >= 85 || canLeft <= 0) {
        canVelocity = canVelocity * -1;
    }

    movingCan.style.left = canLeft + "%";
}

function buildAnswerButtons() {
    answerOptions.replaceChildren();

    const currentOptions = [
        optionAArray[questionNumber],
        optionBArray[questionNumber],
        optionCArray[questionNumber],
        optionDArray[questionNumber]
    ];

    for (let i = 0; i < currentOptions.length; i++) {
        var newButton = document.createElement("button");
        newButton.type = "button";
        newButton.className = "answer-button";
        newButton.id = "answer" + i;
        newButton.innerHTML = currentOptions[i];
        answerOptions.appendChild(newButton);
    }
}

function startRoundTimer() {
    clearInterval(timerIntervalId);
    timeLeft = timeLimit;
    timerDisplay.innerHTML = timeLeft;
    timerBox.classList.remove("warning");

    timerIntervalId = setInterval(function () {
        timeLeft--;
        timerDisplay.innerHTML = timeLeft;

        if (timeLeft <= 3) {
            timerBox.classList.add("warning");
        }

        if (timeLeft <= 0) {
            clearInterval(timerIntervalId);
            handleTimeOut();
        }
    }, 1000);
}

function showQuestion() {
    if (roundNumber >= totalRounds) {
        finishGame();
    } else {
        answerLocked = false;
        questionNumber = (randomStart + roundNumber) % questionArray.length;
        roundDisplay.innerHTML = (roundNumber + 1) + " / " + totalRounds;
        questionText.innerHTML = questionArray[questionNumber];
        feedbackText.innerHTML = "Choose one answer.";
        buildAnswerButtons();

        canLeft = 0;
        canVelocity = 1;

        if (timeLimit == 6) {
            canVelocity = 1.5;
        }

        if (timeLimit == 4) {
            canVelocity = 2;
        }

        movingCan.style.left = canLeft + "%";
        movingCan.classList.remove("bump");
        clearInterval(moveIntervalId);
        moveIntervalId = setInterval(MoveCan, 35);
        startRoundTimer();
    }
}

function queueNextQuestion() {
    roundNumber++;
    nextQuestionTimeoutId = setTimeout(showQuestion, 1100);
}

function handleTimeOut() {
    if (gameIsActive == true) {
        answerLocked = true;
        clearInterval(moveIntervalId);
        feedbackText.innerHTML = "Time up! The correct answer is " +
            answerArray[questionNumber] + ".";
        playSound(wrongAudio);
        queueNextQuestion();
    }
}

// Event delegation: the parent receives clicks from all answer buttons.
answerOptions.addEventListener("click", CheckAnswer);

function CheckAnswer(event) {
    var sender = event.target;

    if (sender.className == "answer-button" &&
        gameIsActive == true && answerLocked == false) {
        answerLocked = true;
        stopGameTimers();

        if (sender.innerHTML == answerArray[questionNumber]) {
            score++;
            scoreDisplay.innerHTML = score;
            sender.classList.add("correct");
            feedbackText.innerHTML = "Correct! " +
                answerArray[questionNumber] + " matches the clue.";
            playSound(correctAudio);
        } else {
            sender.classList.add("wrong");
            feedbackText.innerHTML = "Not quite. The correct answer is " +
                answerArray[questionNumber] + ".";
            playSound(wrongAudio);

            const allAnswerButtons = answerOptions.querySelectorAll(".answer-button");
            for (let oneButton of allAnswerButtons) {
                if (oneButton.innerHTML == answerArray[questionNumber]) {
                    oneButton.classList.add("correct");
                }
            }
        }

        movingCan.classList.add("bump");
        queueNextQuestion();
    }
}

function finishGame() {
    stopGameTimers();
    gameIsActive = false;
    gameArea.style.display = "none";
    resultPanel.style.display = "block";

    if (score == totalRounds) {
        resultTitle.innerHTML = "Perfect can scientist!";
    } else if (score >= 4) {
        resultTitle.innerHTML = "Strong sorting!";
    } else {
        resultTitle.innerHTML = "Good first run!";
    }

    resultMessage.innerHTML = playerDisplay.innerHTML + ", you scored " + score +
        " out of " + totalRounds + ". Review the two learning pages, then try again.";
}

startGameButton.addEventListener("click", function () {
    if (playerName.value != "") {
        const selectedSpeed = document.querySelector("input[name='speed']:checked");

        stopGameTimers();
        roundNumber = 0;
        score = 0;
        timeLimit = parseInt(selectedSpeed.value);
        randomStart = GetRandom(0, questionArray.length - 1);
        gameIsActive = true;

        playerDisplay.innerHTML = playerName.value;
        scoreDisplay.innerHTML = score;
        gameForm.style.display = "none";
        resultPanel.style.display = "none";
        gameArea.style.display = "block";
        playSound(clickAudio);
        showQuestion();
    }
});

function resetGame() {
    stopGameTimers();
    gameIsActive = false;
    answerLocked = false;
    roundNumber = 0;
    score = 0;
    timeLeft = 8;
    canLeft = 0;

    playerName.value = "";
    gameForm.style.display = "grid";
    gameArea.style.display = "none";
    resultPanel.style.display = "none";
    playerDisplay.innerHTML = "-";
    roundDisplay.innerHTML = "1 / 6";
    scoreDisplay.innerHTML = "0";
    timerDisplay.innerHTML = "8";
    timerBox.classList.remove("warning");
    feedbackText.innerHTML = "Choose one answer.";
    answerOptions.replaceChildren();
    movingCan.style.left = "0%";
    playSound(clickAudio);
}

resetButton.addEventListener("click", resetGame);
restartButton.addEventListener("click", resetGame);

// -------------------- RETURN RIGHT MINI-GAME --------------------
const miniSetup = document.querySelector("#miniSetup");
const miniStartButton = document.querySelector("#miniStartButton");
const miniGameArea = document.querySelector("#miniGameArea");
const miniTime = document.querySelector("#miniTime");
const miniScore = document.querySelector("#miniScore");
const miniCaught = document.querySelector("#miniCaught");
const catchCan = document.querySelector("#catchCan");
const miniFeedback = document.querySelector("#miniFeedback");
const miniResult = document.querySelector("#miniResult");
const miniResultTitle = document.querySelector("#miniResultTitle");
const miniResultText = document.querySelector("#miniResultText");
const miniRestartButton = document.querySelector("#miniRestartButton");
const miniResetButton = document.querySelector("#miniResetButton");

var miniGameActive = false;
var miniCanReturnable = true;
var miniTimeLeft = 20;
var miniGameScore = 0;
var miniCorrectCans = 0;
var miniMoveIntervalId;
var miniTimerIntervalId;

function MoveMiniCan() {
    var newLeft = GetRandom(0, 80);
    var newTop = GetRandom(0, 65);
    var canType = GetRandom(0, 1);

    catchCan.style.left = newLeft + "%";
    catchCan.style.top = newTop + "%";

    if (canType == 1) {
        miniCanReturnable = true;
        catchCan.className = "catch-can deposit-can";
        catchCan.innerHTML = "Deposit Mark";
    } else {
        miniCanReturnable = false;
        catchCan.className = "catch-can no-deposit-can";
        catchCan.innerHTML = "No Deposit";
    }
}

function FinishMiniGame() {
    clearInterval(miniMoveIntervalId);
    clearInterval(miniTimerIntervalId);
    miniGameActive = false;
    miniGameArea.style.display = "none";
    miniResult.style.display = "block";

    if (miniCorrectCans >= 10) {
        miniResultTitle.innerHTML = "Excellent return run!";
    } else if (miniCorrectCans >= 5) {
        miniResultTitle.innerHTML = "Good return run!";
    } else {
        miniResultTitle.innerHTML = "Keep checking the mark!";
    }

    miniResultText.innerHTML = "You collected " + miniCorrectCans +
        " eligible cans and finished with " + miniGameScore + " points.";
}

function StartMiniGame() {
    clearInterval(miniMoveIntervalId);
    clearInterval(miniTimerIntervalId);
    miniGameActive = true;
    miniTimeLeft = 20;
    miniGameScore = 0;
    miniCorrectCans = 0;

    miniSetup.style.display = "none";
    miniResult.style.display = "none";
    miniGameArea.style.display = "block";
    miniTime.innerHTML = miniTimeLeft;
    miniScore.innerHTML = miniGameScore;
    miniCaught.innerHTML = miniCorrectCans;
    miniFeedback.innerHTML = "Click only cans with the Deposit Mark.";

    MoveMiniCan();
    miniMoveIntervalId = setInterval(MoveMiniCan, 1000);
    miniTimerIntervalId = setInterval(function () {
        miniTimeLeft--;
        miniTime.innerHTML = miniTimeLeft;

        if (miniTimeLeft <= 0) {
            FinishMiniGame();
        }
    }, 1000);

    playSound(clickAudio);
}

catchCan.addEventListener("click", function () {
    if (miniGameActive == true) {
        if (miniCanReturnable == true) {
            miniGameScore++;
            miniCorrectCans++;
            miniFeedback.innerHTML = "Correct! That can carries the Deposit Mark.";
            playSound(correctAudio);
        } else {
            if (miniGameScore > 0) {
                miniGameScore--;
            }
            miniFeedback.innerHTML = "Wrong can. Look for the Deposit Mark.";
            playSound(wrongAudio);
        }

        miniScore.innerHTML = miniGameScore;
        miniCaught.innerHTML = miniCorrectCans;
        MoveMiniCan();
    }
});

function ResetMiniGame() {
    clearInterval(miniMoveIntervalId);
    clearInterval(miniTimerIntervalId);
    miniGameActive = false;
    miniTimeLeft = 20;
    miniGameScore = 0;
    miniCorrectCans = 0;

    miniSetup.style.display = "block";
    miniGameArea.style.display = "none";
    miniResult.style.display = "none";
    miniTime.innerHTML = "20";
    miniScore.innerHTML = "0";
    miniCaught.innerHTML = "0";
    catchCan.style.left = "0%";
    catchCan.style.top = "0%";
    catchCan.className = "catch-can deposit-can";
    catchCan.innerHTML = "Deposit Mark";
    miniFeedback.innerHTML = "Click only cans with the Deposit Mark.";
    playSound(clickAudio);
}

miniStartButton.addEventListener("click", StartMiniGame);
miniRestartButton.addEventListener("click", ResetMiniGame);
miniResetButton.addEventListener("click", ResetMiniGame);

// Show only the home page when the app first loads.
hideall();
document.querySelector("#home").style.display = "block";
gameArea.style.display = "none";
resultPanel.style.display = "none";
miniGameArea.style.display = "none";
miniResult.style.display = "none";
